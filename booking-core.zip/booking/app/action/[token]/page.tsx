import { admin } from "@/lib/supabase";
import { sendEmail, esc } from "@/lib/email";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";
const TOKEN = /^[a-f0-9]{64}$/;

async function load(token: string) {
  if (!TOKEN.test(token)) return null;
  const { data } = await admin().from("reservations").select("*").eq("action_token", token).maybeSingle();
  return data;
}

// Server Action: POST-only; Next.js enforces Origin/Host match (CSRF protection).
async function act(formData: FormData) {
  "use server";
  const token = String(formData.get("token")), action = String(formData.get("action"));
  if (!TOKEN.test(token) || !["confirm", "reject"].includes(action)) return;
  const db = admin();
  const { data: result } = await db.rpc("process_reservation", { p_token: token, p_action: action });
  if (result === "confirmed" || result === "rejected") { // only a fresh transition emails the customer
    const r = await load(token);
    if (r) {
      const when = `${r.reservation_date} at ${String(r.reservation_time).slice(0, 5)}`;
      const { data: s } = await db.from("restaurant_settings").select("name,address").single();
      const body = result === "confirmed"
        ? `<h2>Your reservation is confirmed</h2><p>Hi ${esc(r.customer_name)}, we look forward to seeing you.</p>
           <p><b>${esc(s?.name ?? "")}</b><br>${esc(s?.address ?? "")}<br>${when}<br>${r.party_size} guests</p>`
        : `<p>Hi ${esc(r.customer_name)}, unfortunately we are unable to accommodate your request for ${when}.
           We're sorry and hope to welcome you another time.</p>`;
      try { await sendEmail(r.customer_email, result === "confirmed" ? "Reservation confirmed" : "About your reservation request", body); }
      catch (e) { console.error("Customer email failed:", (e as Error).message); }
    }
  }
  revalidatePath(`/action/${token}`);
}

export default async function Page({ params, searchParams }: {
  params: Promise<{ token: string }>; searchParams: Promise<{ a?: string }>;
}) {
  const { token } = await params; const { a } = await searchParams;
  const r = await load(token);
  if (!r) return <main className="p-8">Reservation not found.</main>;
  const verb = a === "reject" ? "reject" : "confirm";
  return (
    <main className="mx-auto max-w-md p-8">
      <h1 className="text-2xl font-semibold">Reservation request</h1>
      <dl className="my-4 space-y-1">
        <dt>Name</dt><dd className="font-medium">{r.customer_name}</dd>
        <dt>Date / time</dt><dd className="font-medium">{r.reservation_date} {String(r.reservation_time).slice(0, 5)}</dd>
        <dt>Guests</dt><dd className="font-medium">{r.party_size}</dd>
        <dt>Requests</dt><dd className="font-medium">{r.special_requests ?? "None"}</dd>
        <dt>Status</dt><dd className="font-medium uppercase">{r.status}</dd>
      </dl>
      {r.status === "pending" ? (
        <form action={act}>
          <input type="hidden" name="token" value={token} />
          <input type="hidden" name="action" value={verb} />
          <button className="rounded px-5 py-3 font-bold text-white" style={{ background: verb === "confirm" ? "#15803d" : "#b91c1c" }}>
            {verb === "confirm" ? "Yes, confirm this booking" : "Yes, reject this booking"}
          </button>
        </form>
      ) : <p>This reservation has already been processed. No further action is needed.</p>}
    </main>
  );
}
