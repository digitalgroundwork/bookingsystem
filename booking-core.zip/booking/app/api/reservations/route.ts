import { NextResponse } from "next/server";
import { z } from "zod";
import { admin } from "@/lib/supabase";
import { sendEmail, esc } from "@/lib/email";

const schema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  phone: z.string().trim().regex(/^[+\d\s()-]{5,30}$/),
  party: z.number().int().min(1).max(50),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.string().regex(/^\d{2}:\d{2}$/),
  notes: z.string().max(1000).optional().default(""),
  website: z.string().max(0).optional(), // honeypot
});

export async function GET(req: Request) {
  const p = new URL(req.url).searchParams;
  const date = p.get("date") ?? "", party = Number(p.get("party"));
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isInteger(party) || party < 1)
    return NextResponse.json({ error: "Invalid query" }, { status: 400 });
  const { data, error } = await admin().rpc("available_slots", { d: date, party });
  if (error) return NextResponse.json({ error: "Could not load availability" }, { status: 500 });
  return NextResponse.json({ slots: data.map((r: { slot: string }) => r.slot.slice(0, 5)) });
}

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Please check your details." }, { status: 400 });
  const b = parsed.data;
  if (b.website) return NextResponse.json({ ok: true });
  // TODO: add IP rate limiting (e.g. Upstash Ratelimit) before going live.

  const { data, error } = await admin().rpc("create_reservation", {
    p_name: b.name, p_email: b.email, p_phone: b.phone, p_party: b.party,
    p_date: b.date, p_time: b.time, p_notes: b.notes,
  });
  if (error) {
    const gone = /slot_unavailable|invalid_party_size/.test(error.message);
    return NextResponse.json({ error: gone ? "That time is no longer available." : "Could not save your booking." },
      { status: gone ? 409 : 500 });
  }
  const { action_token } = data[0];
  const base = process.env.APP_URL, to = process.env.RESERVATION_NOTIFICATION_EMAIL;
  try {
    if (!base || !to) throw new Error("APP_URL / RESERVATION_NOTIFICATION_EMAIL not set");
    const btn = (a: string, label: string, bg: string) =>
      `<a href="${base}/action/${action_token}?a=${a}" style="background:${bg};color:#fff;padding:12px 20px;border-radius:6px;text-decoration:none;font-weight:bold;margin-right:8px">${label}</a>`;
    await sendEmail(to, `New booking request: ${b.name}, ${b.party} guests, ${b.date} ${b.time}`,
      `<h2>New reservation request</h2><p><b>Name:</b> ${esc(b.name)}<br><b>Email:</b> ${esc(b.email)}<br>
       <b>Phone:</b> ${esc(b.phone)}<br><b>Date:</b> ${b.date}<br><b>Time:</b> ${b.time}<br>
       <b>Guests:</b> ${b.party}<br><b>Requests:</b> ${esc(b.notes) || "None"}</p>
       <p>${btn("confirm", "CONFIRM BOOKING", "#15803d")}${btn("reject", "REJECT BOOKING", "#b91c1c")}</p>
       <p style="color:#666;font-size:12px">These links open a page where you must press a button to confirm.</p>`);
  } catch (e) {
    console.error("Notification email failed:", (e as Error).message);
    return NextResponse.json({ ok: true, warning: "Booking saved but the restaurant could not be notified." }, { status: 202 });
  }
  return NextResponse.json({ ok: true });
}
