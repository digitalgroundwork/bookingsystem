create extension if not exists pgcrypto;

create table restaurant_settings (
  id int primary key default 1 check (id = 1),
  name text not null default 'Restaurant',
  address text not null default '',
  max_capacity int not null default 40 check (max_capacity > 0),
  duration_minutes int not null default 90 check (duration_minutes > 0),
  slot_interval_minutes int not null default 30 check (slot_interval_minutes > 0),
  pending_hold_minutes int not null default 30 check (pending_hold_minutes > 0),
  max_party_size int not null default 8 check (max_party_size > 0),
  min_notice_minutes int not null default 60,
  -- weekday (0=Sun..6=Sat) -> {"open":"12:00","last":"21:00"} or null when closed
  opening_hours jsonb not null default '{"0":null,"1":{"open":"12:00","last":"21:00"},"2":{"open":"12:00","last":"21:00"},"3":{"open":"12:00","last":"21:00"},"4":{"open":"12:00","last":"21:00"},"5":{"open":"12:00","last":"21:30"},"6":{"open":"12:00","last":"21:30"}}'
);
insert into restaurant_settings default values;

create table reservations (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null check (char_length(customer_name) between 2 and 100),
  customer_email text not null check (char_length(customer_email) <= 254),
  customer_phone text not null check (char_length(customer_phone) between 5 and 30),
  party_size int not null check (party_size > 0),
  reservation_date date not null,
  reservation_time time not null,
  special_requests text check (char_length(special_requests) <= 1000),
  status text not null default 'pending' check (status in ('pending','confirmed','rejected','cancelled')),
  action_token text not null unique default encode(gen_random_bytes(32), 'hex'),
  hold_expires_at timestamptz,
  processed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on reservations (reservation_date, status);
create index on reservations (status, hold_expires_at);

create table staff (user_id uuid primary key references auth.users(id) on delete cascade);

alter table restaurant_settings enable row level security;
alter table reservations enable row level security;
alter table staff enable row level security;
-- No public policies: customers only reach data through server routes (service role).
create policy staff_read on staff for select using (user_id = auth.uid());
create policy staff_res_all on reservations for all
  using (exists (select 1 from staff s where s.user_id = auth.uid()))
  with check (exists (select 1 from staff s where s.user_id = auth.uid()));
create policy staff_set_all on restaurant_settings for all
  using (exists (select 1 from staff s where s.user_id = auth.uid()))
  with check (exists (select 1 from staff s where s.user_id = auth.uid()));

create function seats_at(d date, t timestamp, exclude uuid, dur int) returns int
language sql stable as $$
  select coalesce(sum(party_size),0)::int from reservations r
  where r.reservation_date = d and r.id is distinct from exclude
    and (r.status = 'confirmed' or (r.status = 'pending' and r.hold_expires_at > now()))
    and (d + r.reservation_time) <= t and t < (d + r.reservation_time) + make_interval(mins => dur);
$$;

create function has_capacity(d date, tm time, party int, exclude uuid) returns boolean
language plpgsql stable as $$
declare s restaurant_settings; t timestamp;
begin
  select * into s from restaurant_settings where id = 1;
  for t in select generate_series(d + tm, d + tm + make_interval(mins => s.duration_minutes - 1),
                                  make_interval(mins => s.slot_interval_minutes)) loop
    if seats_at(d, t, exclude, s.duration_minutes) + party > s.max_capacity then return false; end if;
  end loop;
  return true;
end $$;

create function slot_is_valid(d date, tm time) returns boolean
language plpgsql stable as $$
declare s restaurant_settings; h jsonb; o time; l time;
begin
  select * into s from restaurant_settings where id = 1;
  h := s.opening_hours -> extract(dow from d)::int::text;
  if h is null or h = 'null'::jsonb then return false; end if;
  o := (h->>'open')::time; l := (h->>'last')::time;
  return tm between o and l
     and mod((extract(epoch from (tm - o)) / 60)::int, s.slot_interval_minutes) = 0
     and (d + tm) >= (now() at time zone current_setting('TimeZone')) + make_interval(mins => s.min_notice_minutes);
end $$;

create function available_slots(d date, party int) returns table(slot time)
language plpgsql stable as $$
declare s restaurant_settings; h jsonb; t time;
begin
  select * into s from restaurant_settings where id = 1;
  h := s.opening_hours -> extract(dow from d)::int::text;
  if h is null or h = 'null'::jsonb or party > s.max_party_size then return; end if;
  t := (h->>'open')::time;
  while t <= (h->>'last')::time loop
    if slot_is_valid(d, t) and has_capacity(d, t, party, null) then slot := t; return next; end if;
    t := t + make_interval(mins => s.slot_interval_minutes);
  end loop;
end $$;

create function create_reservation(p_name text, p_email text, p_phone text, p_party int,
  p_date date, p_time time, p_notes text) returns table(id uuid, action_token text)
language plpgsql security definer set search_path = public as $$
declare s restaurant_settings; r reservations;
begin
  select * into s from restaurant_settings where restaurant_settings.id = 1;
  if p_party < 1 or p_party > s.max_party_size then raise exception 'invalid_party_size'; end if;
  perform pg_advisory_xact_lock(hashtext(p_date::text));
  if not slot_is_valid(p_date, p_time) then raise exception 'slot_unavailable'; end if;
  if not has_capacity(p_date, p_time, p_party, null) then raise exception 'slot_unavailable'; end if;
  insert into reservations(customer_name, customer_email, customer_phone, party_size,
    reservation_date, reservation_time, special_requests, hold_expires_at)
  values (p_name, p_email, p_phone, p_party, p_date, p_time, nullif(p_notes,''),
    now() + make_interval(mins => s.pending_hold_minutes))
  returning * into r;
  return query select r.id, r.action_token;
end $$;

create function process_reservation(p_token text, p_action text) returns text
language plpgsql security definer set search_path = public as $$
declare r reservations;
begin
  select * into r from reservations where action_token = p_token;
  if not found then return 'not_found'; end if;
  perform pg_advisory_xact_lock(hashtext(r.reservation_date::text));
  select * into r from reservations where id = r.id for update;
  if r.status <> 'pending' then return 'already_' || r.status; end if;
  if p_action = 'confirm' then
    if not has_capacity(r.reservation_date, r.reservation_time, r.party_size, r.id) then return 'no_capacity'; end if;
    update reservations set status='confirmed', processed_at=now(), updated_at=now(), hold_expires_at=null where id=r.id;
    return 'confirmed';
  elsif p_action = 'reject' then
    update reservations set status='rejected', processed_at=now(), updated_at=now(), hold_expires_at=null where id=r.id;
    return 'rejected';
  end if;
  raise exception 'invalid_action';
end $$;

create function expire_pending_holds() returns int
language sql security definer set search_path = public as $$
  with u as (update reservations set status='cancelled', updated_at=now()
             where status='pending' and hold_expires_at < now() returning 1)
  select count(*)::int from u;
$$;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function create_reservation, process_reservation, available_slots, expire_pending_holds to service_role;

-- Enable pg_cron (Database > Extensions), then:
-- select cron.schedule('expire-holds', '* * * * *', 'select expire_pending_holds()');
